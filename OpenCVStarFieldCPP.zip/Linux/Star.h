#pragma once
#include <opencv2/opencv.hpp>
class Star {
public:
	struct Vertex {
		double Wx, Wy, Wz;  // The world X, Y and Z.
	};
	// A "point on the screen" structure:
	struct ScreenVertex {
		long X, Y;
	};
	Vertex point3D;		//local point data
	ScreenVertex point2D;
	int visible;
	cv::Vec3b  color;
	unsigned int intensity;
	Star(double, double, double);
	Star(double, double, double, unsigned char, unsigned char, unsigned char);
	Star();
	~Star();
};

