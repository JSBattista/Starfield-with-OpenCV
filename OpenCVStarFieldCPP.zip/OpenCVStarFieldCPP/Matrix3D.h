#pragma once
#include "Star.h"
#include <math.h>
class Matrix3D {
public:
	Matrix3D();
	~Matrix3D();
	void Rotate(double Xa, double Ya, double Za);
	void Translate(double Xt, double Yt, double Zt);
	void Scale(double Xs, double Ys, double Zs);
	void Shear(double Xs, double Ys);
	void reset();
	void reset(double[4][4]);
	void Transform(Star *);
protected:
	// Protected matrix functions
	void MergeMatrix(double NewMatrix[4][4]);
	void MergeMatrix(double[4][4], double NewMatrix[4][4]);
	void MergeMatrices(double dest[4][4], double source[4][4]);
	double Matrix[4][4];  // This is the main matrix for the world view transformations
};

