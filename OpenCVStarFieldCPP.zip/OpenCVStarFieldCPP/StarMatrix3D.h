#pragma once
class StarMatrix3D
{
private:

	float mainmat[4][4];
	float rotmat[4][4];
	float xr, yr, zr, xtran, ytran, ztran, lx, ly, lz, tx, ty, tz;
	void initialize();
	void mergeMatrix(float[][]);
public:
	void Rotate(double Xa, double Ya, double Za);
	void Translate(double Xt, double Yt, double Zt);
	void Scale(double Xs, double Ys, double Zs);



	void Transform(Star *);
	void Transform(Star *, cv::Vec3f);
	StarMatrix3D();
	~StarMatrix3D();
};

