/*
Star class, the actual containment for position, color, etc. 
*/
#include "Star.h"
#include <cstdlib>
#include <random>
Star::Star() {
	visible = 1;
	// static_cast <double> (rand()) / (static_cast <double> (RAND_MAX/X));
	int MAXVAL = 10000;
	point3D.Wx = static_cast <double> (rand() % 2101 - 1000 / static_cast <double> (RAND_MAX / MAXVAL ));
	point3D.Wy =  static_cast <double> (rand() % 2101 - 1000 / static_cast <double> (RAND_MAX / MAXVAL));
	point3D.Wz =  point3D.Wx / point3D.Wy;// static_cast <double> (rand() % 2101 - 100 / static_cast <double> (RAND_MAX / MAXVAL));
	point2D.X = 0;
	point2D.Y = 0;
	std::random_device seeder;
	std::ranlux48 gen(seeder());
	std::uniform_int_distribution<int>  uniform_0_255(0, 255);
	color[0] = uniform_0_255(gen);
	color[1] = uniform_0_255(gen);
	color[2] = uniform_0_255(gen);
}
Star::Star(double x, double y, double z) {
	point2D.X = 0;
	point2D.Y = 0;
	std::random_device seeder;
	std::ranlux48 gen(seeder());
	std::uniform_int_distribution<int>  uniform_0_255(0, 255);
	color[0] = uniform_0_255(gen);
	color[1] = uniform_0_255(gen);
	color[2] = uniform_0_255(gen);
	visible = 1;
	point3D.Wx = x;
	point3D.Wy = y;
	point3D.Wz = z;
}
Star::Star(double x, double y, double z, unsigned char r, unsigned char g, unsigned char b) {
	point2D.X = 0;
	point2D.Y = 0;
	color[0] = r;
	color[1] = g;
	color[2] = b;
	visible = 1;
	point3D.Wx = x;
	point3D.Wy = y;
	point3D.Wz = z;
}
Star::~Star() {
}