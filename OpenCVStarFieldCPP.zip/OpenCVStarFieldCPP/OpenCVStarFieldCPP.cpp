/** OpenCVStarFieldCPP.cpp

3D starfield sample program based on the sample from the book "Cutting-Edge 3d Game Programming With C++" by John De Goes

Adapted for OpenCV demo by J.S.Battista 10-10-2017
jsbattista@yahoo.com
https://twitter.com/JohnSBattista

Free for use. For further reference to the book, see https://archive.org/details/CE3DC

This is based on Chapter three of the book. Only with some minor changes to use OpenCV. Part of the star field is specially
arranged as a landmark. This is not an infinite starfield.

The idea of this project was to be able to do some simple 3D stuff purely out of code without special libraries. The concept
is rather outdated given what's currently available. But in case where a code-only lightweight solution may be needed
doing something like this as seen in the book and this program might fit the bill.

Once you have down the ability to write pixels to a buffer, and render those pixels, the sky is pretty much the limit. And
this is accomplished at the root with simple matrix math. If you ever wondered what the most atomic level of 3D graphics
could be, this would be one example of it.
Some additional help for Linux:
Is you system capable of OpenCV? Try:
pkg-config opencv --cflags
pkg-config opencv --libs
If not, you need to install at least OpenCV 3.0.
http://docs.opencv.org/3.0-beta/doc/tutorials/introduction/linux_install/linux_install.html
Are there ^M endings in your lines after porting to Linux? Here's what to do:
https://its.ucsc.edu/unix-timeshare/tutorials/clean-ctrl-m.html
*/
#include "stdafx.h"
#include <opencv2/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "Stars.h"
using namespace cv;
using namespace std;
int main(int argc, char** argv) {
	Mat img(600, 800, CV_8UC3, Scalar(0, 0, 0));  // important to handle this "right" with the proper number of channels to use with Vec3B
	Stars cluster;
	if (argc >  1) {
		cluster = Stars(argv[1]);
	} else {
		cluster = Stars();
	}  // if
	double Xr=0 , Yr=0, Zr=0;		// "viewer" orientation in space. 
	double viewX = 0, viewY = 0, viewZ = 0;
	cluster.matrix.Translate(viewX, viewY, -100);
	cluster.matrix.Translate(viewX, viewY, 100);
	char k = ' ';
	cluster.matrix.Translate(0, 0, .05);
	cluster.matrix.Rotate(0, 0, .001);
	for (;;) {
			// The X, Y center of the screen:
		int xcenter = (int)img.size().width / 2;  // The X center of the screen
		int ycenter = (int)img.size().height / 2;  // The Y center of the screen
  	    // The clipping rectangle:
		int XMIN = 0, XMAX = img.size().width - 1, YMIN = 0, YMAX = img.size().height - 1;  // take 1 off the maxes or there will be out of bounds crashes
		cluster.show(img, XMIN, XMAX, YMIN, YMAX, xcenter, ycenter);
		imshow("STARS", img);
		img = Scalar(5, 10, 15);
		k = (char)waitKey(10);
		if (k != 0) {
			if (k == 27) break;
			switch (k) {
				// Translate
			case (119)://  w
				viewZ += -0.10;
				break;
			case (97)://a
				Zr += 0.0010F;
				Yr += 0.0010F;
				break;
			case (115): // s
				viewZ += 0.10;
				break;
			case (100): //d
				Zr += -0.0010F;
				Yr += -0.0010F;
				break;
				// Rotate
			case (116): // roll right
				Zr += -0.0010F;
				break;
			case (114): // pitch up
				Xr += -0.0010F;
				break;
			case (121): // yaw right
				Yr += -0.0010F;
				break;
			case (102): // pitch down
				Xr += 0.0010F;
				break;
			case (103): // roll left
				Zr += 0.0010F;
				break;
			case (104): // Yaw left
				Yr += 0.0010F;
				break;
			case (32): //
				cluster.matrix.reset();
				break;
			default:
				Xr = Yr = Zr = 0.0F;
				viewX = viewY = viewZ = 0.0F;
				break;
			}  // switch
			cluster.matrix.Rotate(Xr, Yr, Zr);
			Xr = Yr = Zr = 0;
			cluster.matrix.Translate(viewX, viewY, viewZ);
			viewX = viewY = viewZ = 0;
		}  // if
	}  // for
	return 0;
}