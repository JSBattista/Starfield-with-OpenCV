#include "StarMatrix3D.h"



StarMatrix3D::StarMatrix3D()
{
}


StarMatrix3D::~StarMatrix3D()
{
}


StarMatrix3D::initialize() {
	mainmat[0][0] = 1; mainmat[0][1] = 0; mainmat[0][2] = 0; mainmat[0][3] = 0;
	mainmat[1][0] = 0; mainmat[1][1] = 1; mainmat[1][2] = 0; mainmat[1][3] = 0;
	mainmat[2][0] = 0; mainmat[2][1] = 0; mainmat[2][2] = 1; mainmat[2][3] = 0;
	mainmat[3][0] = 0; mainmat[3][1] = 0; mainmat[3][2] = 0; mainmat[3][3] = 1;
}


