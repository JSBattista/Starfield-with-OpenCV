/*
Matrix handling class derived from John DeGoes' book. 
Note: all of this matrix operation is "world" coordinates in that we are moving the word around our 
viewpoint, not the stars themselves. It is possible to give each star its own main matrix and make shooting
stars by changing their XYZ location. But that is beyond this demo. 
*/
#include "Matrix3D.h"
#include <opencv2/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
Matrix3D::Matrix3D() {
	Matrix[0][0] = 1;  Matrix[0][1] = 0;  Matrix[0][2] = 0;  Matrix[0][3] = 0;
	Matrix[1][0] = 0;  Matrix[1][1] = 1;  Matrix[1][2] = 0;  Matrix[1][3] = 0;
	Matrix[2][0] = 0;  Matrix[2][1] = 0;  Matrix[2][2] = 1;  Matrix[2][3] = 0;
	Matrix[3][0] = 0;  Matrix[3][1] = 0;  Matrix[3][2] = 0;  Matrix[3][3] = 1;
}
void Matrix3D::reset() {
	Matrix[0][0] = 1;  Matrix[0][1] = 0;  Matrix[0][2] = 0;  Matrix[0][3] = 0;
	Matrix[1][0] = 0;  Matrix[1][1] = 1;  Matrix[1][2] = 0;  Matrix[1][3] = 0;
	Matrix[2][0] = 0;  Matrix[2][1] = 0;  Matrix[2][2] = 1;  Matrix[2][3] = 0;
	Matrix[3][0] = 0;  Matrix[3][1] = 0;  Matrix[3][2] = 0;  Matrix[3][3] = 1;
}
void Matrix3D::reset(double m[4][4]) {
	m[0][0] = 1;  m[0][1] = 0;  m[0][2] = 0;  m[0][3] = 0;
	m[1][0] = 0;  m[1][1] = 1;  m[1][2] = 0;  m[1][3] = 0;
	m[2][0] = 0;  m[2][1] = 0;  m[2][2] = 1;  m[2][3] = 0;
	m[3][0] = 0;  m[3][1] = 0;  m[3][2] = 0;  m[3][3] = 1;
}
Matrix3D::~Matrix3D() {
}
void Matrix3D::MergeMatrix(double NewMatrix[4][4]) {
	// Multiply NewMatirx by Matrix; store result in TempMatrix
	double TempMatrix[4][4];
	for (short unsigned int i = 0; i < 4; i++)
		for (short unsigned int j = 0; j < 4; j++)
			TempMatrix[i][j] = (Matrix[i][0] * NewMatrix[0][j])
			+ (Matrix[i][1] * NewMatrix[1][j])
			+ (Matrix[i][2] * NewMatrix[2][j])
			+ (Matrix[i][3] * NewMatrix[3][j]);
	// Copy TempMatrix to Matrix
	for (short unsigned int i = 0; i < 4; i++)
	{
		Matrix[i][0] = TempMatrix[i][0];
		Matrix[i][1] = TempMatrix[i][1];
		Matrix[i][2] = TempMatrix[i][2];
		Matrix[i][3] = TempMatrix[i][3];
	}
}
void Matrix3D::MergeMatrix(double dest[4][4], double NewMatrix[4][4]) {
	// Multiply NewMatirx by Matrix; store result in TempMatrix
	double TempMatrix[4][4];
	for (short unsigned int i = 0; i < 4; i++)
		for (short unsigned int j = 0; j < 4; j++)
			TempMatrix[i][j] = (dest[i][0] * NewMatrix[0][j])
			+ (dest[i][1] * NewMatrix[1][j])
			+ (dest[i][2] * NewMatrix[2][j])
			+ (dest[i][3] * NewMatrix[3][j]);
	// Copy TempMatrix to Matrix
	for (short unsigned int i = 0; i < 4; i++)
	{
		dest[i][0] = TempMatrix[i][0];
		dest[i][1] = TempMatrix[i][1];
		dest[i][2] = TempMatrix[i][2];
		dest[i][3] = TempMatrix[i][3];
	}
}
void Matrix3D::MergeMatrices(double dest[4][4], double source[4][4]) {	
	/**
	Multiply the specified source matrix by the
	destination matrix.
	Note how this is "unrolled" which was an old school method for increasing speed back in the day.
	Modern optimizers make this uneccesary. 
	*/
	double temp[4][4];
	temp[0][0] = (							//  byte i, j;
		(source[0][0] * dest[0][0])		//  for(i = 0;  i < 4; i++)
		+ (source[0][1] * dest[1][0])		//	{
		+ (source[0][2] * dest[2][0])		//		for(j = 0; j < 4; j++)
		+ (source[0][3] * dest[3][0])		//		{
		);					//			 temp[i][j] =   (
	temp[0][1] = (						    //		     (source[i][0] * dest[0][j])
		(source[0][0] * dest[0][1])		//            + (source[i][1] * dest[1][j])
		+ (source[0][1] * dest[1][1])		//		      + (source[i][2] * dest[2][j])
		+ (source[0][2] * dest[2][1])		//		      + (source[i][3] * dest[3][j]));
		+ (source[0][3] * dest[3][1])		//		 }
		);					//	 }
	temp[0][2] = (
		(source[0][0] * dest[0][2])
		+ (source[0][1] * dest[1][2])
		+ (source[0][2] * dest[2][2])
		+ (source[0][3] * dest[3][2])
		);
	temp[0][3] = (
		(source[0][0] * dest[0][3])
		+ (source[0][1] * dest[1][3])
		+ (source[0][2] * dest[2][3])
		+ (source[0][3] * dest[3][3])
		);
	//-------
	temp[1][0] = (
		(source[1][0] * dest[0][0])
		+ (source[1][1] * dest[1][0])
		+ (source[1][2] * dest[2][0])
		+ (source[1][3] * dest[3][0])
		);
	temp[1][1] = (
		(source[1][0] * dest[0][1])
		+ (source[1][1] * dest[1][1])
		+ (source[1][2] * dest[2][1])
		+ (source[1][3] * dest[3][1])
		);
	temp[1][2] = (
		(source[1][0] * dest[0][2])
		+ (source[1][1] * dest[1][2])
		+ (source[1][2] * dest[2][2])
		+ (source[1][3] * dest[3][2])
		);
	temp[1][3] = (
		(source[1][0] * dest[0][3])
		+ (source[1][1] * dest[1][3])
		+ (source[1][2] * dest[2][3])
		+ (source[1][3] * dest[3][3])
		);
	//------
	temp[2][0] = (
		(source[2][0] * dest[0][0])
		+ (source[2][1] * dest[1][0])
		+ (source[2][2] * dest[2][0])
		+ (source[2][3] * dest[3][0])
		);
	temp[2][1] = (
		(source[2][0] * dest[0][1])
		+ (source[2][1] * dest[1][1])
		+ (source[2][2] * dest[2][1])
		+ (source[2][3] * dest[3][1])
		);
	temp[2][2] = (
		(source[2][0] * dest[0][2])
		+ (source[2][1] * dest[1][2])
		+ (source[2][2] * dest[2][2])
		+ (source[2][3] * dest[3][2])
		);
	temp[2][3] = (
		(source[2][0] * dest[0][3])
		+ (source[2][1] * dest[1][3])
		+ (source[2][2] * dest[2][3])
		+ (source[2][3] * dest[3][3])
		);
	//----------
	temp[3][0] = (
		(source[3][0] * dest[0][0])
		+ (source[3][1] * dest[1][0])
		+ (source[3][2] * dest[2][0])
		+ (source[3][3] * dest[3][0])
		);
	temp[3][1] = (
		(source[3][0] * dest[0][1])
		+ (source[3][1] * dest[1][1])
		+ (source[3][2] * dest[2][1])
		+ (source[3][3] * dest[3][1])
		);
	temp[3][2] = (
		(source[3][0] * dest[0][2])
		+ (source[3][1] * dest[1][2])
		+ (source[3][2] * dest[2][2])
		+ (source[3][3] * dest[3][2])
		);
	temp[3][3] = (
		(source[3][0] * dest[0][3])
		+ (source[3][1] * dest[1][3])
		+ (source[3][2] * dest[2][3])
		+ (source[3][3] * dest[3][3])
		);
	//--------
	dest[0][0] = temp[0][0];		//	for (i = 0; i < 4; i++)
	dest[0][1] = temp[0][1];		//	{
	dest[0][2] = temp[0][2];		//		dest[i][0] = temp[i][0];
	dest[0][3] = temp[0][3];		//		dest[i][1] = temp[i][1];
									//		dest[i][2] = temp[i][2];
	dest[1][0] = temp[1][0];		//		dest[i][3] = temp[i][3];
	dest[1][1] = temp[1][1];		//	}
	dest[1][2] = temp[1][2];
	dest[1][3] = temp[1][3];

	dest[2][0] = temp[2][0];
	dest[2][1] = temp[2][1];
	dest[2][2] = temp[2][2];
	dest[2][3] = temp[2][3];

	dest[3][0] = temp[3][0];
	dest[3][1] = temp[3][1];
	dest[3][2] = temp[3][2];
	dest[3][3] = temp[3][3];
}
void Matrix3D::Rotate(double Xa, double Ya, double Za) {
	double Rmat[4][4];
	// Initialize Z rotation matrix (aligning 3D world with 2D screen):
	Rmat[0][0] = cos(Za);  Rmat[0][1] = sin(Za);  Rmat[0][2] = 0;    Rmat[0][3] = 0;
	Rmat[1][0] = -sin(Za); Rmat[1][1] = cos(Za);  Rmat[1][2] = 0;    Rmat[1][3] = 0;
	Rmat[2][0] = 0;        Rmat[2][1] = 0;        Rmat[2][2] = 1;    Rmat[2][3] = 0;
	Rmat[3][0] = 0;        Rmat[3][1] = 0;        Rmat[3][2] = 0;    Rmat[3][3] = 1;
	// Merge matrix with master matrix:
	MergeMatrix(Rmat);
	// Initialize X rotation matrix:
	Rmat[0][0] = 1; Rmat[0][1] = 0;        Rmat[0][2] = 0;       Rmat[0][3] = 0;
	Rmat[1][0] = 0; Rmat[1][1] = cos(Xa);  Rmat[1][2] = sin(Xa); Rmat[1][3] = 0;
	Rmat[2][0] = 0; Rmat[2][1] = -sin(Xa); Rmat[2][2] = cos(Xa); Rmat[2][3] = 0;
	Rmat[3][0] = 0; Rmat[3][1] = 0;        Rmat[3][2] = 0;       Rmat[3][3] = 1;
	// Merge matrix with master matrix:
	MergeMatrix(Rmat);
	// Initialize Y rotation matrix:
	Rmat[0][0] = cos(Ya); Rmat[0][1] = 0; Rmat[0][2] = -sin(Ya); Rmat[0][3] = 0;
	Rmat[1][0] = 0;       Rmat[1][1] = 1; Rmat[1][2] = 0;        Rmat[1][3] = 0;
	Rmat[2][0] = sin(Ya); Rmat[2][1] = 0; Rmat[2][2] = cos(Ya);  Rmat[2][3] = 0;
	Rmat[3][0] = 0;       Rmat[3][1] = 0; Rmat[3][2] = 0;        Rmat[3][3] = 1;
	// Merge matrix with master matrix:
	MergeMatrix(Rmat);
}
void Matrix3D::Translate(double Xt, double Yt, double Zt) {
	double Tmat[4][4];
	// Initialize translation matrix:
	Tmat[0][0] = 1;  Tmat[0][1] = 0;  Tmat[0][2] = 0;  Tmat[0][3] = 0;
	Tmat[1][0] = 0;  Tmat[1][1] = 1;  Tmat[1][2] = 0;  Tmat[1][3] = 0;
	Tmat[2][0] = 0;  Tmat[2][1] = 0;  Tmat[2][2] = 1;  Tmat[2][3] = 0;
	Tmat[3][0] = Xt; Tmat[3][1] = Yt; Tmat[3][2] = Zt; Tmat[3][3] = 1;
	// Merge matrix with master matrix:
	MergeMatrix(Tmat);
}
void Matrix3D::Scale(double Xs, double Ys, double Zs) {
	double Smat[4][4];
	// Initialize scaling matrix:
	Smat[0][0] = Xs; Smat[0][1] = 0;  Smat[0][2] = 0;  Smat[0][3] = 0;
	Smat[1][0] = 0;  Smat[1][1] = Ys; Smat[1][2] = 0;  Smat[1][3] = 0;
	Smat[2][0] = 0;  Smat[2][1] = 0;  Smat[2][2] = Zs; Smat[2][3] = 0;
	Smat[3][0] = 0;  Smat[3][1] = 0;  Smat[3][2] = 0;  Smat[3][3] = 1;
	// Merge matrix with master matrix:
	MergeMatrix(Smat);
}
void Matrix3D::Shear(double Xs, double Ys) {
	double Smat[4][4];
	// Initialize shearing matrix:
	Smat[0][0] = 1;  Smat[0][1] = 0;  Smat[0][2] = Xs;  Smat[0][3] = 0;
	Smat[1][0] = 0;  Smat[1][1] = 1;  Smat[1][2] = Ys;  Smat[1][3] = 0;
	Smat[2][0] = 0;  Smat[2][1] = 0;  Smat[2][2] = 1;   Smat[2][3] = 0;
	Smat[3][0] = 0;  Smat[3][1] = 0;  Smat[3][2] = 0;   Smat[3][3] = 1;
	// Merge matrix with master matrix:
	MergeMatrix(Smat);
}
// Transform the WORLD point of the star (how the view sees it, not the location of the star itself) with the main matrix for the world, works with the "camera"
void Matrix3D::Transform(Star *s) {
	// Initialize temporary variables:
	double OldX = s->point3D.Wx;
	double OldY = s->point3D.Wy;
	double OldZ = s->point3D.Wz;
	// Transform vertex using master matrix (vector*matrix):
	s->point3D.Wx = OldX * Matrix[0][0] +
					OldY * Matrix[1][0] +
					OldZ * Matrix[2][0] +
						   Matrix[3][0];
	s->point3D.Wy = OldX * Matrix[0][1] +
					OldY * Matrix[1][1] +
					OldZ * Matrix[2][1] +
						   Matrix[3][1];
	s->point3D.Wz = OldX * Matrix[0][2] +
					OldY * Matrix[1][2] +
					OldZ * Matrix[2][2] +
						   Matrix[3][2];
}