/*
Stars.cpp - this class holds the array of Star classes and performs opertions on them. 
*/
#include "Stars.h"
#include "Star.h"
#include <cstdlib>
#include "Matrix3D.h"
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <random>
#define	scale 200   // This will scale the pixels, the higher the values the bigger the star cluster
#define zclip 10000 // The clipping distance on the Z axis
Stars::Stars() {
	starfield[0] = (const Star&)Star(0,0,0);  // dead center star
	for (int incr = 0; incr < 500; incr++) {  // Lined up stars for reference (what other algorithms are possible?)
		int h = incr;
		starfield[incr++] = (const Star&)Star(-100, 100, h * 4);
		starfield[incr++] = (const Star&)Star(100, 100, h * 4);
		starfield[incr++] = (const Star&)Star(-100, -100, h * 4);
		starfield[incr] = (const Star&)Star(100, -100, h * 4);
	}  // for
	for (int incr = 500; incr < MAXSTARS - 1; incr++) {  // Now make the rest random
		int randrange = 10000;
		starfield[incr] = (const Star&)Star(rand() - randrange, rand() - randrange, (rand() % -randrange));
	}  // for
}
// Instead of a star field, use an input image. 
Stars::Stars(char* s) {
	cv::Mat image;
	image = imread(s, cv::IMREAD_COLOR); // Read the file
	printf("Using image %s height = %i, wirdth = %i\n", s, image.size().height, image.size().width);
	int xrange = 0;
	int yrange = 0;
	int tick = 0; 
	for (int incr = 0; incr < image.size().height * image.size().width; incr++) {
		cv::Vec3b clr = image.at<cv::Vec3b>(incr);
		starfield[incr] = (const Star&)Star(xrange++, yrange, 1, clr[0], clr[1], clr[2]);
		if (xrange > image.size().width) {
			xrange = 0;
			tick++;
			yrange++;
		} // if
	}  // for
}
Stars::~Stars() {
}
void Stars::Project(int centerX, int centerY, unsigned int xmin, unsigned int xmax, unsigned int ymin, unsigned int ymax, Star *s) {
	// If star is far away, adjust "visible" flag accordingly:
	if (s->point3D.Wz > zclip)
		s->visible = 0;
	else if (s->point3D.Wz < 1.0F) {
		s->visible = 0;
	} else {  //http://edspi31415.blogspot.com/2012/09/cartesian-coordinates-to-pixel-screen.html
		// Else star is probably visible - project:
		s->visible = 1;
		double OneOverZ = scale / s->point3D.Wz;
		s->point2D.X = (long)s->point3D.Wx * OneOverZ + centerX;
		s->point2D.Y = (long)s->point3D.Wy  * OneOverZ + centerY;
	}  // if
}

void Stars::drawPoint(cv::Mat &Buffer, unsigned int xmin, unsigned int xmax, unsigned int ymin, unsigned int ymax, Star *s) {
	int Sx = s->point2D.X;
	int Sy = s->point2D.Y;
	// Make sure point is in clipping boundary:
	if ((Sx >= xmin) && (Sx <= xmax) &&
		(Sy >= ymin) && (Sy <= ymax)) {
		// Find memory location:
		try{
			Buffer.at<cv::Vec3b>(cv::Point(Sx, Sy)) =  s->color;
		} catch (cv::Exception& e) {
			const char* err_msg = e.what();
			std::cout << "exception caught: " << err_msg << std::endl;
		}  // try
	}  // if
}
// Display the star on the linear buffer "Buffer"
void Stars::show(cv::Mat &Buffer, unsigned int xmin, unsigned int xmax, unsigned int ymin, unsigned int ymax, int centerX, int centerY) {	
	for (int incr = 0; incr < MAXSTARS; incr++) {
		// Transform point:
		matrix.Transform(&starfield[incr]);
		// Project point:
		Project(centerX, centerY, xmin, xmax, ymin, ymax, &starfield[incr]);
		// If star is still visible...
		if (starfield[incr].visible == 1) {
			// ...draw it:
			drawPoint(Buffer, xmin, xmax, ymin, ymax, &starfield[incr]);
		}  // if
	}  // for
}