#pragma once
#include "Matrix3D.h"
#include "Star.h"
#include <opencv2/core.hpp>
#define MAXSTARS  5000  // ***WARNING*** there is a limit to how many stars you can have. Too many might crash the program
class Stars {
protected:
	// Protected data:
	Star starfield[MAXSTARS];	// Start with 1000 stars for the heck of it
	// Protected member functions:
	void Project(int, int, unsigned int, unsigned int, unsigned int, unsigned int, Star*);
	void drawPoint(cv::Mat&, unsigned int, unsigned int, unsigned int, unsigned int, Star*);
public:
	// Public functions:
	Matrix3D matrix;
	void show(cv::Mat&, unsigned int, unsigned int, unsigned int, unsigned int, int, int);
	// Constructors:
	Stars();
	Stars(char *);
	~Stars();
};
